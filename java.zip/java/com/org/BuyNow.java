package com.org;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BuyNow")
public class BuyNow extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String pro1=request.getParameter("input1");
		String pro2=request.getParameter("input2");
		String pro3=request.getParameter("input3");
		String pro4=request.getParameter("input4");
		String pro5=request.getParameter("input5");
		
		PrintWriter out=response.getWriter();
		
		try {
			//Register the driver class
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Establish Connection 
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ ecommerce" ,"root","root");
			
			//Create Statement
			Statement stat=con.createStatement();
			
			//Execute Query
			stat.executeUpdate("insert into productlist(name,price) values ('"+pro1+"','"+pro2+"','"+pro3+"','"+pro4+"','"+pro5+"')");
			
			/* out.println("Data inserted successfully!!"); */
			response.sendRedirect("ap.jsp");
			
			//Close Connection
			con.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	
	}

}
