package com.org;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Login")
public class Login extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String user = request.getParameter("input1");
		  String pass = request.getParameter("input2");
		  PrintWriter out = response.getWriter();
		  response.setContentType("text/html");
		  
		  try {
			  Class.forName("com.mysql.cj.jdbc.Driver");
			  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce" ,"root","root");
			  PreparedStatement ps = con.prepareStatement("select * from signup where username=? and password=?");
			  ps.setString(1, user);
			  ps.setString(2, pass);
			  ResultSet rs = ps.executeQuery();
			  
			  while(rs.next()) {
				  
				  RequestDispatcher rd = request.getRequestDispatcher("cart.jsp");
				  rd.include(request, response);
				  HttpSession session = request.getSession();
				  session.setAttribute("ses_name", rs.getString("fullname"));
				  session.setAttribute("ses_email", rs.getString("email"));
				  session.setAttribute("ses_user", rs.getString("username"));
				  session.setAttribute("ses_pass", rs.getString("password"));
				  
				 
			  }
			  
			  
		  }catch(Exception e) {
			  e.printStackTrace();
			  out.print("Try Again ,Invaild username or password!!");
		
	}

	}
}
